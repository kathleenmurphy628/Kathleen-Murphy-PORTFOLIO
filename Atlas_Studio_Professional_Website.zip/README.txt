ATLAS STUDIO - EDITABLE WEBSITE

Open index.html to start. Pages: About, Services, Projects, Pricing, Contact.
Edit text in each HTML file, design in style.css, interactions in script.js, and images in assets/images.
All content, names, prices and projects are sample content and should be replaced with the real person/business information.
